from .pexels import Pexels

def setup(bot):
    bot.add_cog(Pexels(bot))
